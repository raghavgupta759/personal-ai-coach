# QA Test Plan

## Authentication and authorization
- Register valid user; reject invalid email and weak password.
- Duplicate registration gives safe error.
- Login/logout/session expiry work.
- User A cannot read User B's documents, analysis, sessions, chat or PDFs by guessing IDs.
- Password reset response does not reveal account existence.
- API keys/passwords never appear in browser bundle, URL or logs.

## Upload/parsing
- Valid PDF and DOCX resume parse successfully.
- Valid JD paste/upload works.
- Reject executable, renamed malicious file, unsupported MIME and oversized file.
- Empty, password-protected, corrupt and scanned PDF show clear recoverable messages.
- Extracted text can be edited and saved.
- User can delete file; associated records follow documented retention rules.

## Analysis
- Valid resume/JD generates structured output.
- Malformed model response is handled and does not crash UI.
- Resume facts are not invented; evidence snippets refer to actual text.
- Requirements correctly support matched/partial/missing/not-assessable.
- Company facts have source URLs and dates; unsupported questions are labeled practice questions.
- Search/API outage shows fallback and does not fabricate citations.

## Interview
- Three types have distinct coverage.
- One question is shown at a time; next question appears only after answer submission.
- Default target is 20 minutes; elapsed time uses server timestamps.
- Early end is accurately recorded.
- Pause/resume and network retry do not duplicate turns.
- Repeated submission is idempotent or safely rejected.
- Text mode works if microphone permission is denied or speech API is unavailable.
- Voice transcript can be edited before scoring.
- Feedback includes rubric scores, evidence, corrections and a practical next step.
- English grammar feedback does not unfairly penalize technical correctness; dimensions remain separate.

## Ask Me and study pack
- Ask Me uses only current user's authorized context.
- Follow-up questions preserve conversation context.
- Clear/delete chat works.
- PDF includes target role/company, sourced company facts, HR/technical/project sections, revision plan and caveats.
- Long PDFs wrap text, handle page breaks and support Unicode.
- Download route enforces ownership and uses private storage.

## UX and accessibility
- Desktop and mobile layouts do not overflow.
- Every button works and has loading/disabled/error states.
- Keyboard-only navigation and visible focus work.
- Reduced-motion preference is respected.
- Empty, loading, success, and error states are tested.

## Release gate
Run and record:
- formatter/linter
- type checker
- unit tests
- integration tests
- end-to-end smoke tests
- production build
- dependency/security scan where available
- full user journey: register → upload → analyze → interview → feedback → Ask Me → PDF → history
Do not call the app production-ready if critical tests are failing.
